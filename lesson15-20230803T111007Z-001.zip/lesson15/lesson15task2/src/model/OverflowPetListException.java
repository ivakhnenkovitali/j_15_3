package model;

public class OverflowPetListException extends Exception {
}
