package model;

public class NullDoubleArrayException extends Exception{
    public NullDoubleArrayException() {
    }

    public NullDoubleArrayException(String message) {
        super(message);
    }
}
