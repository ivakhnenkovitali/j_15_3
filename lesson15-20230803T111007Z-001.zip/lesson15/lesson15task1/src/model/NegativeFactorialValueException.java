package model;

public class NegativeFactorialValueException extends Exception {
    private int negValue;

    public NegativeFactorialValueException(int negValue) {
        this.negValue = negValue;
    }

    public NegativeFactorialValueException(String message, int negValue) {
        super(message);
        this.negValue = negValue;
    }

    @Override
    public String toString() {
        return "NegativeFactorialValueException{" +
                "negValue=" + negValue +
                ", message='" + getMessage() + '\'' +
                '}';
    }
}
