package model;

public class CreateFactorialException extends Exception{

    public CreateFactorialException() {
    }

    public CreateFactorialException(String message) {
        super(message);
    }

    public CreateFactorialException(Throwable cause) {
        super(cause);
    }

    @Override
    public String toString() {
        return "CreateFactorialException{" +
                "message='" + getMessage() + '\'' +
                ", cause=" + getCause() +
                '}';
    }
}
